from manim import *
import numpy as np

class DualDependencyTrees(Scene):
    def construct(self):
        self.camera.background_color = "#000000"

        # =====================================================
        # CONFIG
        # =====================================================
        dx = 0.55              # horizontal node spacing
        dy_fine = 0.4          # vertical spacing fine Δt
        dy_coarse = dy_fine * 2
        n_layers_fine = 6
        n_layers_coarse = n_layers_fine // 2 + 1
        spacing = 6.5          # MORE separation between trees
        y_top = 1.2            # pushed further down

        node_color = BLUE_B
        target_color = RED
        line_color = GRAY_B

        # =====================================================
        # HELPER TO BUILD TRIANGULAR TREE COORDINATES
        # =====================================================
        def build_tree(x_center, y_top, n_layers, dx, dy):
            layers = []
            for k in range(n_layers + 1):
                y = y_top - k * dy
                num_pts = 2 * k + 1
                x_start = x_center - dx * (num_pts - 1) / 2
                pts = [np.array([x_start + i * dx, y, 0]) for i in range(num_pts)]
                layers.append(pts)
            return layers

        fine_layers = build_tree(-spacing / 2, y_top, n_layers_fine, dx, dy_fine)
        coarse_layers = build_tree(+spacing / 2, y_top, n_layers_coarse, dx, dy_coarse)
        coarse_layers = coarse_layers[:-1]  # remove last layer

        # =====================================================
        # TEXT
        # =====================================================
        title = Text("Fixed final time: Δt = 2×Δt₀ skips intermediate layers",
                     color=WHITE, font_size=30).to_edge(UP)
        label_fine = Text("Δt = 1×Δt₀", font_size=28, color=WHITE).next_to(fine_layers[0][0], UP * 1.4)
        label_coarse = Text("Δt = 2×Δt₀", font_size=28, color=WHITE).next_to(coarse_layers[0][0], UP * 1.4)

        self.play(Write(title))
        self.wait(0.4)
        self.play(FadeIn(label_fine), FadeIn(label_coarse))

        # =====================================================
        # NEW CONNECTIVITY FUNCTION — 1-3 pattern
        # =====================================================
        def get_parents_1to3(i, len_child, len_parent):
            """
            For each child node, connect to up to 3 nearest parents in previous layer.
            """
            if len_parent == 1:
                return [0]
            rel = i / (len_child - 1)
            parent_center = rel * (len_parent - 1)
            offsets = [-1, 0, 1]
            parents = []
            for o in offsets:
                idx = int(round(parent_center + o))
                if 0 <= idx < len_parent:
                    parents.append(idx)
            return sorted(set(parents))

        # =====================================================
        # TREE ANIMATION FUNCTION
        # =====================================================
        def build_tree_anim(layers, node_color=node_color, target_color=target_color, run_time=4):
            anims = []
            top_dot = Dot(layers[0][0], color=target_color, radius=0.08)
            anims.append(GrowFromCenter(top_dot))
            all_dots = [top_dot]

            for k in range(1, len(layers)):
                lines = []
                dots = [Dot(p, color=node_color, radius=0.05) for p in layers[k]]
                for i, p in enumerate(layers[k]):
                    parents = get_parents_1to3(i, len(layers[k]), len(layers[k - 1]))
                    for parent_idx in parents:
                        lines.append(Line(layers[k - 1][parent_idx], p,
                                          color=line_color, stroke_width=1, stroke_opacity=0.7))
                anims += [Create(l) for l in lines]
                anims += [FadeIn(d, scale=0.5) for d in dots]
                all_dots += dots
            return LaggedStart(*anims, lag_ratio=0.03, run_time=run_time), top_dot

        # =====================================================
        # ANIMATE SEQUENTIALLY (fine then coarse)
        # =====================================================
        anim_fine, top_fine = build_tree_anim(fine_layers, run_time=4.5)
        anim_coarse, top_coarse = build_tree_anim(coarse_layers, run_time=4.5)

        self.play(anim_fine)
        self.wait(1)
        self.play(anim_coarse)
        self.wait(1)

        self.play(
            Indicate(top_fine, color=YELLOW, scale_factor=1.3),
            Indicate(top_coarse, color=YELLOW, scale_factor=1.3)
        )
        self.wait(2)

